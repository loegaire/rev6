# Description

Hello everyone!  

I am excited to share my 9th crackme, created for the very first CTF hosted by crackmes.one.  
Your mission is to find the correct serial number, to unlock the hidden flag-  
Good luck!  

Fatmike  

# Supported OS

Tested on Windows 10 and Windows 11.  
Due to weird behavior on one specific Windows 11 25H2 computer, i added "administrator required" as manifest.  
This fixed the issue.  

# Architecture

x86  

# Language

C/C++  